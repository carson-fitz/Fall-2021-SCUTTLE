# Fall 2021 SCUTTLE
Obstacle avoidance SCUTTLE using Jetson Nano and stereoscopic camera.
MXET 300-504, Team 10
